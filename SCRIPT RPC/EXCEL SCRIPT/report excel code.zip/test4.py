from openpyxl import load_workbook
from openpyxl import Workbook
from openpyxl.utils import get_column_letter

import odoorpc, csv

from openpyxl.styles import colors
from openpyxl.styles import Font, Color
from openpyxl.styles import Border, Side, PatternFill, Font, GradientFill, Alignment

usuario = 'admin'
password = 'spiderboras'
odoo = odoorpc.ODOO('sidur.galartec.com', port=8069)
odoo.login('sidur2020', usuario, password)

partida = odoo.env['partidas.partidas'].search([('nombre_partida', '=', 'SIDUR-ED-20-003.1871')])

nombre_partida = ''
contratista = ''

workbook = load_workbook(filename="ok.xlsx")
sheet = workbook.active
wb = Workbook()

fill = PatternFill(fill_type=None,  start_color='bdbdbd', end_color='bdbdbd')
double = Side(border_style="double", color="000000")
thin = Side(border_style="thin", color="000000")

for i in partida:
    b_partida = odoo.env['partidas.partidas'].browse(i)
    nombre_partida = b_partida.nombre_partida
    contratista = b_partida.contratista.name

    estimacion = odoo.env['control.estimaciones'].search([('obra.id', '=', b_partida.id)]) # , ('idobra', '=', '1')
    estimacion_c = odoo.env['control.estimaciones'].search_count([('obra.id', '=', b_partida.id)]) # , ('idobra', '=', '1')
    acum = 0
    pos_concepto = 0
    aviso = 0
    variable1 = ''
    variable2 = ''
    variable3 = 0
    variable4 = 0
    xd = 0
    for y in b_partida.conceptos_partidas:
        pos_concepto += 1
        if str(y.medida) == 'False':
            y.medida = ''
        if str(y.cantidad) == '0.0':
            y.cantidad = ''
        if str(y.precio_unitario) == '0.0':
            y.precio_unitario = ''
        if str(y.importe) == '0.0':
            y.importe = ''

        # AVISO INDICA CUANDO HAY QUE APLICAR SUBTOTAL
        acum += 1 + aviso
        # CLAVE
        for column in range(2, 3):
            column_letter = get_column_letter(column)
            xd = acum + 10
            aviso = 0
            if not y.precio_unitario or str(y.precio_unitario) == '':
                if pos_concepto > 2:
                    # SUBTOTALES
                    sheet[column_letter + str(xd)] = 'SUBTOTALES'
                    sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="ff7043")
                    sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                    aviso = 1
                    # SIGUIENTE CATEGORIA CALVE
                    sheet[column_letter + str(xd + 1)] = str(y.clave_linea)
                    sheet[column_letter + str(xd + 1)].alignment = Alignment(wrap_text=True)
                    sheet[column_letter + str(xd + 1)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                    sheet[column_letter + str(xd + 1)].font = Font(bold=True, size=9)
                    sheet[column_letter + str(xd + 1)].fill = PatternFill("solid", fgColor="bdbdbd")
                else:
                    # CLAVES
                    sheet[column_letter + str(xd)] = str(y.clave_linea)
                    sheet[column_letter + str(xd)].alignment = Alignment(wrap_text=True)
                    sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                    sheet[column_letter + str(xd)].font = Font(bold=True, size=9)
                    sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
            else:
                # CLAVE NORMAL
                sheet[column_letter + str(xd)] = str(y.clave_linea)
                sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)

        # CONCEPTO
        for column in range(3, 4):
            column_letter = get_column_letter(column)
            # escribe en la celda
            xd = acum + 10 + aviso
            aviso = 0
            sheet[column_letter + str(xd)] = str(y.concepto)
            sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
            if not y.precio_unitario or str(y.precio_unitario) == '':
                if pos_concepto > 2:
                    sheet[column_letter + str(xd - 1)] = ''
                    sheet[column_letter + str(xd - 1)].fill = PatternFill("solid", fgColor="ff7043")
                    aviso = 1
                sheet[column_letter + str(xd)].font = Font(bold=True, size=9)
                sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
        # UNIDAD
        for column in range(4, 5):
            column_letter = get_column_letter(column)
            # escribe en la celda
            xd = acum + 10 + aviso
            aviso = 0
            sheet[column_letter + str(xd)] = str(y.medida)
            sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)

            if not y.precio_unitario or str(y.precio_unitario) == '':
                if pos_concepto > 2:
                    sheet[column_letter + str(xd - 1)].fill = PatternFill("solid", fgColor="ff7043")
                    aviso = 1
                sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
        # CANTIDAD
        letra = 0

        for column in range(5, 6):
            column_letter = get_column_letter(column)
            # escribe en la celda
            xd = acum + 10 + aviso
            aviso = 0
            if not y.precio_unitario or str(y.precio_unitario) == '':
                if pos_concepto > 2:
                    sheet[column_letter + str(xd - 1)] = "=SUM(E" + str(variable1) + ":E" + str(xd - 2) + ")"
                    sheet[column_letter + str(xd - 1)].fill = PatternFill("solid", fgColor="ff7043")
                    sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
                    aviso = 1
                    # ESTA VARIABLE ALMACENA LA POSICION INICIAL PARA LA SUMA
                    variable1 = str(xd+1)
                else:
                    sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
                    # ESTA VARIABLE ALMACENA LA POSICION INICIAL PARA LA SUMA
                    variable1 = str(xd+1)
            else:
                letra += 1
                sheet[column_letter + str(xd)] = y.cantidad
                sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)

        # PRECIO UNITARIO
        for column in range(6, 7):
            column_letter = get_column_letter(column)
            # escribe en la celda
            xd = acum + 10 + aviso
            aviso = 0
            if not y.precio_unitario or str(y.precio_unitario) == '':
                if pos_concepto > 2:
                    sheet[column_letter + str(xd - 1)] = "=SUM(F" + str(variable2) + ":F" + str(xd - 2) + ")"
                    sheet[column_letter + str(xd - 1)].fill = PatternFill("solid", fgColor="ff7043")
                    sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
                    aviso = 1
                    # ESTA VARIABLE ALMACENA LA POSICION INICIAL PARA LA SUMA
                    variable2 = str(xd + 1)
                else:
                    sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
                    # ESTA VARIABLE ALMACENA LA POSICION INICIAL PARA LA SUMA
                    variable2 = str(xd + 1)
            else:
                letra += 1
                sheet[column_letter + str(xd)] = y.precio_unitario
                sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)

        # IMPORTE
        for column in range(7, 8):
            column_letter = get_column_letter(column)
            # escribe en la celda
            xd = acum + 10 + aviso
            aviso = 0
            if not y.precio_unitario or str(y.precio_unitario) == '':
                if pos_concepto > 2:
                    sheet[column_letter + str(xd - 1)] = "=SUM(G" + str(variable3) + ":G" + str(xd - 2) + ")"
                    sheet[column_letter + str(xd - 1)].fill = PatternFill("solid", fgColor="ff7043")
                    sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
                    aviso = 1
                    # ESTA VARIABLE ALMACENA LA POSICION INICIAL PARA LA SUMA
                    variable3 = str(xd + 1)
                else:
                    sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
                    # ESTA VARIABLE ALMACENA LA POSICION INICIAL PARA LA SUMA
                    variable3 = str(xd + 1)
            else:
                letra += 1
                sheet[column_letter + str(xd)] = y.importe
                sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
    contador_est = 0
    xy = 0

    # SUBTOTAL ULTIMO
    column_letter = get_column_letter(2)
    column_letter_1 = get_column_letter(5)
    column_letter_2 = get_column_letter(6)
    column_letter_3 = get_column_letter(7)
    sheet[column_letter + str(xd + 1)] = 'SUBTOTALES'
    sheet[column_letter + str(xd + 1)].fill = PatternFill("solid", fgColor="ff7043")
    sheet[column_letter + str(xd + 1)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
    for column in range(3, 8):
        column_letter = get_column_letter(column)
        sheet[column_letter + str(xd + 1)] = ''
        sheet[column_letter + str(xd + 1)].fill = PatternFill("solid", fgColor="ff7043")
        sheet[column_letter + str(xd + 1)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
    # CANTIDAD, PRECIO U., IMPORTE
    sheet[column_letter_1 + str(xd + 1)] = "=SUM(E" + str(variable3) + ":E" + str(xd) + ")"
    sheet[column_letter_2 + str(xd + 1)] = "=SUM(F" + str(variable3) + ":F" + str(xd) + ")"
    sheet[column_letter_3 + str(xd + 1)] = "=SUM(G" + str(variable3) + ":G" + str(xd) + ")"

    # ESTIMACIONES
    xd2 = 0
    for x in estimacion:
        contador_est += 1
        b_est = odoo.env['control.estimaciones'].browse(x)
        if contador_est == 1:
            estx = 8
            esty = 9
            imporx = 9
            impory = 10
        else:
            estx = int(xy)
            esty = int(estx + 1)
            imporx = int(esty)
            impory = int(esty + 1)
        xy = 0
        print(' LA ESTIMACION ES', b_est.idobra, )
        acumx = 0
        acum_est = 0
        pos_concepto2 = 0
        kk = 0
        for y in b_est.conceptos_partidas:

            # CONVERTIR 0'S A VACIOS
            if str(y.estimacion) == '0.0':
                y.estimacion = ''
            if str(y.importe_ejecutado) == '0.0':
                y.importe_ejecutado = ''

            acumx += 1
            # cantidad
            for column in range(estx, esty):
                column_letter = get_column_letter(column)
                column_letterest = get_column_letter(column+1)
                # escribe en la celda
                xdx = 10
                sheet[column_letter + str(xdx)] = 'CANTIDAD'
                sheet[column_letter + str(xdx)].font = Font(name='Arial', size=9, bold=True)
                sheet[column_letter + str(xdx)].fill = PatternFill("solid", fgColor="ffff00")
                sheet[column_letter + '9'] = 'ESTIMACION ' + str(b_est.idobra)
                sheet[column_letter + '9'].alignment = Alignment(horizontal="center", vertical="center")
                sheet.merge_cells('J9:K9')
                sheet[column_letterest + '9'].fill = PatternFill("solid", fgColor="ffff00")
                sheet[column_letter + '9'].fill = PatternFill("solid", fgColor="ffff00")
                sheet[column_letter + '9'].font = Font(name='Arial', size=9, bold=True)
                sheet[column_letter + '10'].fill = PatternFill("solid", fgColor="ffff00")
                sheet[column_letter + '9'].border = Border(top=thin, left=thin, right=thin, bottom=thin)
            for column in range(imporx, impory):
                column_letter = get_column_letter(column)
                # escribe en la celda
                xdx = 10
                sheet[column_letter + str(xdx)] = 'IMPORTE'
                sheet[column_letter + str(xdx)].font = Font(name='Arial', size=9, bold=True)
                sheet[column_letter + str(10)].fill = PatternFill("solid", fgColor="ffff00")
                sheet[column_letter + str(10)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
            # ESTIMADO

            '''for column in range(estx, esty):
                column_letter = get_column_letter(column)
                # escribe en la celda
                xdx = acumx + 10
                sheet[column_letter + str(xdx)] = y.estimacion
                sheet[column_letter + str(xdx)].border = Border(top=thin, left=thin, right=thin, bottom=thin)'''

            acum_est += 1 + aviso
            # CANTIDAD ESTIMADA
            for column in range(estx, xy):
                pos_concepto2 += 1
                column_letter = get_column_letter(column)
                xd = acum_est + 10
                kk += 1
                if kk == 1:
                    variable4 = str(xd)
                aviso = 0
                if not y.precio_unitario or str(y.precio_unitario) == '':
                    if pos_concepto2 > 2:
                        # SUBTOTALES
                        sheet[column_letter + str(xd)] = ''
                        # sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="ff7043")
                        sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                        aviso = 1
                        # SIGUIENTE CATEGORIA CALVE
                        sheet[column_letter + str(xd + 1)] = y.estimacion
                        sheet[column_letter + str(xd + 1)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                        sheet[column_letter + str(xd + 1)].font = Font(bold=True, size=9)
                        # sheet[column_letter + str(xd + 1)].fill = PatternFill("solid", fgColor="bdbdbd")
                    else:
                        # ESTIMADO PRIMERO
                        sheet[column_letter + str(xd)] = y.estimacion
                        sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                        sheet[column_letter + str(xd)].font = Font(bold=True, size=9)
                        # sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
                else:
                    # ESTIMADO NORMAL
                    sheet[column_letter + str(xd)] = y.estimacion
                    sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)

            # IMPORTE EJECUTADO
            for column in range(imporx, impory):
                column_letter = get_column_letter(column)
                # escribe en la celda
                xd2 = acum_est + 10
                sheet[column_letter + str(xd2)] = y.importe_ejecutado
                sheet[column_letter + str(xd2)].number_format = '[$$-409]#,##0.00;[RED]-[$$-409]#,##0.00' # CURRENCY
                sheet[column_letter + str(xd2)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
            xy = impory

        # CICLO PARA SACAR LA CANTIDAD TOTAL DE LAS ESTIMACIONES
        acumy = 0
        pos_concepto3 = 0

        for o in b_est.conceptos_partidas:
            pos_concepto3 += 1
            if str(o.precio_unitario) == '0.0':
                o.precio_unitario = ''
            acumy += 1 + aviso
            # T.CANTIDAD
            for column in range(xy, xy + 1):
                column_letter = get_column_letter(column)
                pos = 8
                xd2 = acumy + 10
                column_letterx = ''
                column_lettery = ''
                aviso = 0
                continuacion = ''
                letra = 0
                pasar = 0
                # CICLO PARA ACUMULAR FORMULAS DE CADA LINEA
                for i in range(estimacion_c):
                    pasar += 1
                    # pasar los ultimos dos registros
                    if pasar <= (estimacion_c - 2):
                        letra += 2
                        column_lettery2 = get_column_letter((pos + 2) + letra)
                        # STRING ACUMULADO
                        continuacion += ',' + str(column_lettery2 + str(xd2))
                    else:
                        pass
                column_letterx = get_column_letter(pos)
                column_lettery = get_column_letter(pos + 2)
                if not o.precio_unitario or str(o.precio_unitario) == '':
                    if pos_concepto3 > 2:
                        # SUBTOTALES
                        sheet[column_letter + str(xd2)] = ''
                        # sheet[column_letter + str(xd2)].fill = PatternFill("solid", fgColor="ff7043")
                        sheet[column_letter + str(xd2)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                        aviso = 1
                        # SIGUIENTE CATEGORIA CALVE
                        # FORMULA PARA SUMAR
                        sheet[column_letter + str(xd2+1)] = ''  # "=SUM(" + column_letterx + str(xd2+1) + "," + column_lettery + str(xd2+1) + continuacion + ")"
                        sheet[column_letter + str(xd2+1)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                        sheet[column_letter + str(xd2 + 1)].font = Font(bold=True, size=9)
                    else:
                        # ESTIMADO PRIMERO
                        # FORMULA PARA SUMAR
                        sheet[column_letter + str(xd2)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                        sheet[column_letter + str(xd2)].font = Font(bold=True, size=9)
                        # sheet[column_letter + str(xd2)].fill = PatternFill("solid", fgColor="bdbdbd")
                else:
                    # FORMULA PARA SUMAR
                    sheet[column_letter + str(xd2)] = "=SUM(" + column_letterx + str(
                        xd2) + "," + column_lettery + str(xd2) + continuacion + ")"
                    sheet[column_letter + str(xd2)].border = Border(top=thin, left=thin, right=thin, bottom=thin)

            # T.IMPORTE
            for column in range(xy + 1, xy + 2):
                column_letter = get_column_letter(column)
                pos = 9
                xd2 = acumy + 10
                column_letterx = ''
                column_lettery = ''
                if estimacion_c > 1:
                    continuacion = ''
                    letra = 0
                    pasar = 0
                    # CICLO PARA ACUMULAR FORMULAS DE CADA LINEA
                    for i in range(estimacion_c):
                        pasar += 1
                        # pasar los ultimos dos registros
                        if pasar <= (estimacion_c - 2):
                            letra += 2
                            column_lettery2 = get_column_letter((pos + 2) + letra)
                            # STRING ACUMULADO
                            continuacion += ',' + str(column_lettery2 + str(xd2))
                        else:
                            pass
                    column_letterx = get_column_letter(pos)
                    column_lettery = get_column_letter(pos + 2)
                    # FORMULA PARA SUMAR
                    if not o.precio_unitario or str(o.precio_unitario) == '':
                        # es categoria o subtotal
                        sheet[column_letter + str(xd2)] = ''
                        sheet[column_letter + str(xd2)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                    else:
                        sheet[column_letter + str(xd2)] = "=SUM(" + column_letterx + str(xd2) + "," + column_lettery + str(xd2) + continuacion + ")"
                        sheet[column_letter + str(xd2)].number_format = '[$$-409]#,##0.00;[RED]-[$$-409]#,##0.00'
                        sheet[column_letter + str(xd2)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                else:
                    # SINO POR DEFECTO
                    column_letterx = get_column_letter(9)
                    # sheet[column_letter + str(xd2)] = "=SUM(" + column_letterx + str(xd2) + "," + 'K' + str(xd2) + ")"
                    sheet[column_letter + str(xd2)].number_format = '[$$-409]#,##0.00;[RED]-[$$-409]#,##0.00'
                    sheet[column_letter + str(xd2)].border = Border(top=thin, left=thin, right=thin, bottom=thin)

    # SUMATORIA TOTAL ------------------------------------------------------------------------------------
    column_letteru = get_column_letter(xy-1) # TOTAL
    column_letter_3 = get_column_letter(xy) # TOTAL CANTIDAD
    column_letter_4 = get_column_letter(xy+1) # TOTAL IMPORTE
    sheet[column_letteru + str(xd2+1)] = 'TOTAL'
    sheet[column_letteru + str(xd2+1)].number_format = '[$$-409]#,##0.00;[RED]-[$$-409]#,##0.00'
    sheet[column_letteru + str(xd2+1)].fill = PatternFill("solid", fgColor="ff7043")
    sheet[column_letteru + str(xd2+1)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
    '''last_acum = 0
    for column in range(8, xd2+1):
        last_acum += 1
        last = 8 + last_acum
        column_letterh = get_column_letter(column)
        # sheet[column_letteru + str(xd2 + 1)] = ''
        sheet[column_letterh + str(last)].fill = PatternFill("solid", fgColor="ff7043")
        sheet[column_letterh + str(last)].border = Border(top=thin, left=thin, right=thin, bottom=thin)'''
    # TOTAL CANTIDAD, TOTAL IMPORTE
    sheet[column_letter_3 + str(xd2 + 1)] = "=SUM(" + column_letter_3 + str(variable4) + ":" + column_letter_3 + str(xd2) + ")"
    sheet[column_letter_3 + str(xd2 + 1)].fill = PatternFill("solid", fgColor="66bb6a")
    sheet[column_letter_3 + str(xd2 + 1)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
    sheet[column_letter_3 + str(xd2 + 1)].font = Font(color="fafafa", name='Arial', size=9)
    sheet[column_letter_4 + str(xd2 + 1)] = "=SUM(" + column_letter_4 + str(variable4) + ":" + column_letter_4 + str(xd2) + ")"
    sheet[column_letter_4 + str(xd2 + 1)].number_format = '[$$-409]#,##0.00;[RED]-[$$-409]#,##0.00'
    sheet[column_letter_4 + str(xd2 + 1)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
    sheet[column_letter_4 + str(xd2 + 1)].fill = PatternFill("solid", fgColor="66bb6a")
    sheet[column_letter_4 + str(xd2 + 1)].font = Font(color="fafafa", name='Arial', size=9)
    # print("=SUM(E" + str(variable3) + ":E" + str(xd) + ")")
    # sheet[column_letter_4 + str(xd2 + 1)] = "=SUM(F" + column_letter + ":F" + str(xd2) + ")"

    # TOTALES
    for column in range(xy, xy + 1):
        column_letter = get_column_letter(column)
        # escribe en la celda
        xd2 = 10
        sheet[column_letter + str(xd2)] = 'T.CANTIDAD'
        sheet[column_letter + str(xd2)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
        sheet[column_letter + str(xd2)].fill = PatternFill("solid", fgColor="e65100")
        sheet[column_letter + str(xd2)].font = Font(color="fafafa", name='Arial', size=9)
        sheet[column_letter + '9'] = 'TOTALES '
        sheet[column_letter + '9'].border = Border(top=thin, left=thin, right=thin, bottom=thin)
        sheet[column_letter + '9'].fill = PatternFill("solid", fgColor="e65100")
        sheet[column_letter + '9'].font = Font(color="fafafa", name='Arial', size=9)
    for column in range(xy + 1, xy + 2):
        column_letter = get_column_letter(column)
        # escribe en la celda
        xdx = 10
        sheet[column_letter + str(xdx)] = 'T.IMPORTE'
        sheet[column_letter + str(xdx)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
        sheet[column_letter + str(xdx)].fill = PatternFill("solid", fgColor="e65100")
        sheet[column_letter + str(xdx)].font = Font(color="fafafa", name='Arial', size=9)

for column in range(7,8):
    column_letter = get_column_letter(column)
    #escribe en la celda
    sheet[column_letter + "7"] = nombre_partida

for column in range(2,3):
    column_letter = get_column_letter(column)
    #escribe en la celda
    sheet[column_letter + "7"] = contratista

# Save the spreadsheet
workbook.save(filename="resultado.xlsx")
