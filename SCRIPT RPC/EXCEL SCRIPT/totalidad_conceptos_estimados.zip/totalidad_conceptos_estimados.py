from openpyxl import load_workbook
from openpyxl import Workbook
from openpyxl.utils import get_column_letter

import odoorpc, csv

from openpyxl.styles import colors
from openpyxl.styles import Font, Color
from openpyxl.styles import Border, Side, PatternFill, Font, GradientFill, Alignment

usuario = 'admin'
password = 'spiderboras'
odoo = odoorpc.ODOO('sidur.galartec.com', port=8069)
odoo.login('sidur2020', usuario, password)

partida = odoo.env['partidas.partidas'].search([('nombre_partida', '=', 'SIDUR-ED-19-130.1770')])

nombre_partida = ''
contratista = ''

workbook = load_workbook(filename="ok.xlsx")
sheet = workbook.active
wb = Workbook()

fill = PatternFill(fill_type=None,  start_color='bdbdbd', end_color='bdbdbd')
double = Side(border_style="double", color="000000")
thin = Side(border_style="thin", color="000000")

for i in partida:
    b_partida = odoo.env['partidas.partidas'].browse(i)
    nombre_partida = b_partida.nombre_partida
    contratista = b_partida.contratista.name

    estimacion = odoo.env['control.estimaciones'].search([('obra.id', '=', b_partida.id)]) # , ('idobra', '=', '1')
    estimacion_c = odoo.env['control.estimaciones'].search_count([('obra.id', '=', b_partida.id)]) # , ('idobra', '=', '1')
    acum = 0
    pos_concepto = 0
    aviso = 0
    variable1 = ''
    variable2 = ''
    variable3 = 0
    variable4 = 0
    variable5 = 0
    xd = 0
    for y in b_partida.conceptos_partidas:
        pos_concepto += 1
        if str(y.medida) == 'False':
            y.medida = ''
        if str(y.cantidad) == '0.0':
            y.cantidad = ''
        if str(y.precio_unitario) == '0.0':
            y.precio_unitario = ''
        if str(y.importe) == '0.0':
            y.importe = ''

        # AVISO INDICA CUANDO HAY QUE APLICAR SUBTOTAL
        acum += 1 + aviso
        # CLAVE
        for column in range(2, 3):
            column_letter = get_column_letter(column)
            xd = acum + 10
            aviso = 0
            if not y.precio_unitario or str(y.precio_unitario) == '':
                if pos_concepto > 2:
                    # SUBTOTALES
                    sheet[column_letter + str(xd)] = 'SUBTOTAL'
                    sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="ff7043")
                    sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                    aviso = 1
                    # SIGUIENTE CATEGORIA CALVE
                    sheet[column_letter + str(xd + 1)] = str(y.clave_linea)
                    sheet[column_letter + str(xd + 1)].alignment = Alignment(wrap_text=True)
                    sheet[column_letter + str(xd + 1)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                    sheet[column_letter + str(xd + 1)].font = Font(bold=True, size=9)
                    sheet[column_letter + str(xd + 1)].fill = PatternFill("solid", fgColor="bdbdbd")
                else:
                    # CLAVES
                    sheet[column_letter + str(xd)] = str(y.clave_linea)
                    sheet[column_letter + str(xd)].alignment = Alignment(wrap_text=True)
                    sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                    sheet[column_letter + str(xd)].font = Font(bold=True, size=9)
                    sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
            else:
                # CLAVE NORMAL
                sheet[column_letter + str(xd)] = str(y.clave_linea)
                sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)

        # CONCEPTO
        for column in range(3, 4):
            column_letter = get_column_letter(column)
            xd = acum + 10 + aviso
            aviso = 0
            sheet[column_letter + str(xd)] = str(y.concepto)
            sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
            if not y.precio_unitario or str(y.precio_unitario) == '':
                if pos_concepto > 2:
                    sheet[column_letter + str(xd - 1)] = ''
                    sheet[column_letter + str(xd - 1)].fill = PatternFill("solid", fgColor="ff7043")
                    aviso = 1
                sheet[column_letter + str(xd)].font = Font(bold=True, size=9)
                sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
        # UNIDAD
        for column in range(4, 5):
            column_letter = get_column_letter(column)
            xd = acum + 10 + aviso
            aviso = 0
            sheet[column_letter + str(xd)] = str(y.medida)
            sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
            if not y.precio_unitario or str(y.precio_unitario) == '':
                if pos_concepto > 2:
                    sheet[column_letter + str(xd - 1)].fill = PatternFill("solid", fgColor="ff7043")
                    aviso = 1
                sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
        # CANTIDAD
        letra = 0

        for column in range(5, 6):
            column_letter = get_column_letter(column)
            xd = acum + 10 + aviso
            aviso = 0
            if not y.precio_unitario or str(y.precio_unitario) == '':
                if pos_concepto > 2:
                    # sheet[column_letter + str(xd - 1)] = "=SUM(E" + str(variable1) + ":E" + str(xd - 2) + ")"
                    sheet[column_letter + str(xd - 1)].fill = PatternFill("solid", fgColor="ff7043")
                    sheet[column_letter + str(xd - 1)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                    sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
                    aviso = 1
                    variable1 = str(xd+1) # ESTA VARIABLE ALMACENA LA POSICION INICIAL PARA LA SUMA
                else:
                    sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
                    sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                    variable1 = str(xd+1) # ESTA VARIABLE ALMACENA LA POSICION INICIAL PARA LA SUMA
            else:
                letra += 1
                sheet[column_letter + str(xd)] = y.cantidad
                sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)

        # PRECIO UNITARIO
        for column in range(6, 7):
            column_letter = get_column_letter(column)
            xd = acum + 10 + aviso
            aviso = 0
            if not y.precio_unitario or str(y.precio_unitario) == '':
                if pos_concepto > 2:
                    # sheet[column_letter + str(xd - 1)] = "=SUM(F" + str(variable2) + ":F" + str(xd - 2) + ")"
                    sheet[column_letter + str(xd - 1)].fill = PatternFill("solid", fgColor="ff7043")
                    sheet[column_letter + str(xd - 1)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                    sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
                    sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                    aviso = 1
                    # ESTA VARIABLE ALMACENA LA POSICION INICIAL PARA LA SUMA
                    variable2 = str(xd + 1)
                else:
                    sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
                    sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                    # ESTA VARIABLE ALMACENA LA POSICION INICIAL PARA LA SUMA
                    variable2 = str(xd + 1)
            else:
                letra += 1
                sheet[column_letter + str(xd)] = y.precio_unitario
                sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)

        # IMPORTE
        for column in range(7, 8):
            column_letter = get_column_letter(column)
            # escribe en la celda
            xd = acum + 10 + aviso
            aviso = 0
            if not y.precio_unitario or str(y.precio_unitario) == '':
                if pos_concepto > 2:
                    sheet[column_letter + str(xd - 1)] = "=SUM(G" + str(variable3) + ":G" + str(xd - 2) + ")"
                    sheet[column_letter + str(xd - 1)].fill = PatternFill("solid", fgColor="ff7043")
                    sheet[column_letter + str(xd - 1)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                    sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
                    sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                    aviso = 1
                    # ESTA VARIABLE ALMACENA LA POSICION INICIAL PARA LA SUMA
                    variable3 = str(xd + 1)
                else:
                    sheet[column_letter + str(xd)].fill = PatternFill("solid", fgColor="bdbdbd")
                    sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                    # ESTA VARIABLE ALMACENA LA POSICION INICIAL PARA LA SUMA
                    variable3 = str(xd + 1)
            else:
                letra += 1
                sheet[column_letter + str(xd)] = y.importe
                sheet[column_letter + str(xd)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
    contador_est = 0
    xy = 0

    # SUBTOTAL ULTIMO
    column_letter = get_column_letter(2)
    column_letter_1 = get_column_letter(5)
    column_letter_2 = get_column_letter(6)
    column_letter_3 = get_column_letter(7)
    sheet[column_letter + str(xd + 1)] = 'SUBTOTAL'
    sheet[column_letter + str(xd + 1)].fill = PatternFill("solid", fgColor="ff7043")
    sheet[column_letter + str(xd + 1)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
    for column in range(3, 8):
        column_letter = get_column_letter(column)
        sheet[column_letter + str(xd + 1)] = ''
        sheet[column_letter + str(xd + 1)].fill = PatternFill("solid", fgColor="ff7043")
        sheet[column_letter + str(xd + 1)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
    # CANTIDAD, PRECIO U., IMPORTE
    sheet[column_letter_1 + str(xd + 1)] = "=SUM(E" + str(variable3) + ":E" + str(xd) + ")"
    sheet[column_letter_2 + str(xd + 1)] = "=SUM(F" + str(variable3) + ":F" + str(xd) + ")"
    sheet[column_letter_3 + str(xd + 1)] = "=SUM(G" + str(variable3) + ":G" + str(xd) + ")"

    # ----------------X-------------  ESTIMACIONES -------------X-------------
    xd2 = 0
    acum_est = 0
    xy = 0
    posicion_estimacion = 0
    for x in estimacion:
        contador_est += 1
        # CONDICION DE ACUMULADOR PARA DETECTAR LAS CASILLAS DE CANTIDAD ESTIMADA PARA LA SUMATORIA
        if contador_est == 1:
            pass
        else:
            posicion_estimacion += 2

        b_est = odoo.env['control.estimaciones'].browse(x)
        if contador_est == 1:
            estx = 8
            esty = 9
            imporx = 9
            impory = 10
        else:
            estx = int(xy)
            esty = int(estx + 1)
            imporx = int(esty)
            impory = int(esty + 1)

        print(' LA ESTIMACION ES', b_est.idobra, )
        acumx = 0

        pos_concepto2 = 0
        kk = 0
        acumy = 0
        pos_concepto3 = 0
        for y in b_est.conceptos_partidas:  # CICLO PRINCIPAL DE CONCEPTOS DE ESTIMACION

            concepto = y.concepto
            # CONVERTIR 0'S A VACIOS
            if str(y.estimacion) == '0.0':
                y.estimacion = ''
            if str(y.importe_ejecutado) == '0.0':
                y.importe_ejecutado = ''

            acumx += 1
            # -----------------------  COLUMNAS DE LAS ESTIMACIONES -----------------------------
            for column in range(estx, esty):
                column_letter = get_column_letter(column)
                column_letterest = get_column_letter(column+1)
                # escribe en la celda
                num_pos = 10
                sheet[column_letter + str(num_pos)] = 'CANTIDAD'
                sheet[column_letter + str(num_pos)].font = Font(name='Arial', size=9, bold=True)
                sheet[column_letter + str(num_pos)].fill = PatternFill("solid", fgColor="ffff00")
                sheet[column_letter + '9'] = 'ESTIMACION ' + str(b_est.idobra)
                sheet[column_letter + '9'].alignment = Alignment(horizontal="center", vertical="center")
                sheet.merge_cells("" + column_letter + "9:" + column_letterest + "9")
                sheet[column_letterest + '9'].fill = PatternFill("solid", fgColor="ffff00")
                sheet[column_letter + '9'].fill = PatternFill("solid", fgColor="ffff00")
                sheet[column_letter + '9'].font = Font(name='Arial', size=9, bold=True)
                sheet[column_letter + '10'].fill = PatternFill("solid", fgColor="ffff00")
                sheet[column_letter + '9'].border = Border(top=thin, left=thin, right=thin, bottom=thin)
            for column in range(imporx, impory):
                column_letter = get_column_letter(column)
                # escribe en la celda
                num_pos = 10
                sheet[column_letter + str(num_pos)] = 'IMPORTE'
                sheet[column_letter + str(num_pos)].font = Font(name='Arial', size=9, bold=True)
                sheet[column_letter + str(10)].fill = PatternFill("solid", fgColor="ffff00")
                sheet[column_letter + str(10)].border = Border(top=thin, left=thin, right=thin, bottom=thin)

            # ---------------------------------- ESTIMADOS --------------------------------------
            acum_est += 1 + aviso
            if contador_est == 1:
                xy = 10
            clave_sub = 0
            for column_estimado in range(imporx-1, imporx):
                column_letter_esti = get_column_letter(column_estimado)
                xd = acum_est + 10
                aviso = 0
                clave_inicial = get_column_letter(2)
                clave_cat = get_column_letter(6)
                acum_clave = 0
                acum_clave_ = 0
                acum_clavexxx = 0 # CATEGORIA
                clave = ''
                for k in b_partida.conceptos_partidas:
                    acum_clave += 1 + clave_sub
                    acum_clavexxx += 1
                    clave_sub = 0
                    clave = sheet[clave_inicial + str(acum_clave + 9)].value
                    categoria = sheet[clave_cat + str(acum_clave + 10)].value

                    # SI LA LINEA ES SUBTOTAL IGNORAR
                    if str(clave) == 'SUBTOTAL':
                        acum_clave_ += 1
                        clave_sub = 1
                        sheet[column_letter_esti + str(acum_clave + 10)].fill = PatternFill("solid", fgColor="bdbdbd")
                        sheet[column_letter_esti + str(acum_clave + 11)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                        sheet[column_letter_esti + str(acum_clave + 10)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                        # -----------------  SUBTOTAL DE CANTIDAD
                        # EXCEPCION DE PRIMER CICLO
                        if variable4 > acum_clave + 8:
                            variable4 = acum_clave_ + 10
                        if int(b_est.idobra) == 1:
                            letra_columna_est = get_column_letter(column_estimado)
                            # variable4 = 11
                        else:
                            letra_columna_est = get_column_letter(8 + posicion_estimacion)
                        letra = letra_columna_est

                        sheet[column_letter_esti + str(
                            acum_clave + 9)] = "=SUM(" + letra + str(variable4) + ":" + letra + str(acum_clave + 8) + ")"

                        sheet[column_letter_esti + str(acum_clave + 9)].fill = PatternFill("solid", fgColor="ff7043")
                        sheet[column_letter_esti + str(acum_clave + 9)].border = Border(top=thin, left=thin, right=thin,
                                                                                        bottom=thin)
                        variable4 = acum_clave + 11
                    else:
                        clave_sub = 0

                        if not categoria: # CATEGORIA AGREGAR STILO
                            sheet[column_letter_esti + str(acum_clave + 10)].fill = PatternFill("solid", fgColor="bdbdbd")

                        # SI EL CONCEPTO DEL CICLO ES IGUAL AL DEL CATALOGO, INSERTAR EN ESA POSICION
                        if str(y.clave_linea) == str(clave):
                            sheet[column_letter_esti + str(acum_clave + 9)] = y.estimacion
                            sheet[column_letter_esti + str(acum_clave + 9)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                        else:
                            sheet[column_letter_esti + str(acum_clave + 10)].border = Border(top=thin, left=thin, right=thin, bottom=thin)

            # ULTIMO SUBTOTAL DE CANTIDAD
            sheet[column_letter_esti + str(
                acum_clave + 11)] = "=SUM(" + letra + str(variable4) + ":" + letra + str(acum_clave + 10) + ")"
            sheet[column_letter_esti + str(acum_clave + 11)].fill = PatternFill("solid", fgColor="ff7043")
            sheet[column_letter_esti + str(acum_clave + 11)].border = Border(top=thin, left=thin, right=thin,
                                                                            bottom=thin)

            # -------------------------   IMPORTE EJECUTADO ESTIMACION ----------------------------------
            clave_subx = 0
            for column in range(imporx, impory):
                clave_inicial = get_column_letter(2)
                clave_cat = get_column_letter(6)
                acum_clavex = 0
                acum_clave_ = 0
                clave = ''
                column_letterc = get_column_letter(column)
                for k in b_partida.conceptos_partidas:
                    acum_clavex += 1 + clave_subx
                    categoria = sheet[clave_cat + str(acum_clavex + 10)].value
                    clave_subx = 0
                    clave = sheet[clave_inicial + str(acum_clavex + 9)].value
                    # SI LA LINEA ES SUBTOTAL IGNORAR
                    if str(clave) == 'SUBTOTAL':
                        acum_clave_ += 1
                        clave_subx = 1
                        # CAT
                        sheet[column_letterc + str(acum_clavex + 10)].fill = PatternFill("solid", fgColor="bdbdbd")
                        sheet[column_letterc + str(acum_clavex + 10)].border = Border(top=thin, left=thin, right=thin,
                                                                                    bottom=thin)
                        # EXCEPCION DE PRIMER CICLO
                        if variable5 > acum_clavex + 8:
                            variable5 = acum_clave_ + 10
                        if int(b_est.idobra) == 1:
                            letra_columna_estimp = get_column_letter(column)
                        else:
                            letra_columna_estimp = get_column_letter(9 + posicion_estimacion)
                        letra_importe = letra_columna_estimp
                        # SUB
                        sheet[column_letterc + str(acum_clavex + 9)] = "=SUM(" + letra_importe + str(variable5) + ":" \
                                                                       + letra_importe + str(acum_clavex + 8) + ")"
                        sheet[column_letterc + str(acum_clavex + 9)].fill = PatternFill("solid", fgColor="ff7043")
                        sheet[column_letterc + str(acum_clavex + 9)].number_format = '[$$-409]#,##0.00;[RED]-[$$-409]#,##0.00'
                        sheet[column_letterc + str(acum_clavex + 9)].border = Border(top=thin, left=thin, right=thin,
                                                                                        bottom=thin)
                        variable5 = acum_clavex + 11
                    else:
                        clave_subx = 0

                        if not categoria: # PRIMERA CATEGORIA STYLE
                            sheet[column_letterc + str(acum_clavex + 10)].fill = PatternFill("solid", fgColor="bdbdbd")

                        # SI EL CONCEPTO DEL CICLO COINCIDE CON EL DEL CATALOGO, INSERTAR EN ESA POSICION
                        if str(y.clave_linea) == str(clave):
                            sheet[column_letterc + str(acum_clavex + 9)] = y.importe_ejecutado
                            sheet[column_letterc + str(acum_clavex + 9)].number_format = '[$$-409]#,##0.00;[RED]-[$$-409]#,##0.00' # CURRENCY
                            sheet[column_letterc + str(acum_clavex + 9)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                            xy = impory
                        else:
                            sheet[column_letterc + str(acum_clavex + 10)].border = Border(top=thin, left=thin, right=thin, bottom=thin)

                sheet[column_letterc + str(acum_clavex + 15)] = b_est.estimado  # TOTAL ESTIMADO DE CADA ESTIMACION x-x
                sheet[column_letterc + str(acum_clavex + 15)].fill = PatternFill("solid", fgColor="2898B9")
                sheet[column_letterc + str(acum_clavex + 15)].number_format = '[$$-409]#,##0.00;[RED]-[$$-409]#,##0.00'

            # ULTIMO SUBTOTAL DE IMPORTE
            sheet[column_letterc + str(acum_clavex + 11)] = "=SUM(" + letra_importe + str(variable5) + ":" \
                                                           + letra_importe + str(acum_clavex + 10) + ")"
            sheet[column_letterc + str(acum_clavex + 11)].fill = PatternFill("solid", fgColor="ff7043")
            sheet[column_letterc + str(acum_clavex + 11)].number_format = '[$$-409]#,##0.00;[RED]-[$$-409]#,##0.00'
            sheet[column_letterc + str(acum_clavex + 11)].border = Border(top=thin, left=thin, right=thin,
                                                                         bottom=thin)

            pos_concepto3 += 1
            if str(y.precio_unitario) == '0.0':
                y.precio_unitario = ''
            acumy += 1 + aviso
            # ----------------------------------------- T.CANTIDAD y T.IMPORTE------------------------------------------
            pos_total1 = 8 + (estimacion_c * 2)
            pos_total2 = 8 + (estimacion_c * 2) + 1
            for column in range(pos_total1, pos_total2):
                column_letter = get_column_letter(column)
                column_letter_timporte = get_column_letter(pos_total2)
                clave_inicial = get_column_letter(2)
                acum_clavex = 0
                clave_subx = 0
                clave = ''
                acum_linea_total = 0
                for k in b_partida.conceptos_partidas:
                    acum_clavex += 1 + clave_subx
                    clave = sheet[clave_inicial + str(acum_clavex + 9)].value
                    if str(clave) == 'SUBTOTAL':
                        acum_linea_total += 1
                        clave_subx = 1
                        sheet[column_letter + str(acum_clavex + 9)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                        sheet[column_letter_timporte + str(acum_clavex + 9)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                        sheet[column_letter + str(acum_clavex + 10)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                        sheet[column_letter_timporte + str(acum_clavex + 10)].border = Border(top=thin, left=thin,
                                                                                             right=thin, bottom=thin)
                    else:
                        continuacion = ''
                        continuacion_tim = ''
                        letra = 0
                        pasar = 0
                        pos = 8
                        xd2 = acumy + 10
                        column_letterx = ''
                        column_lettery = ''
                        aviso = 0
                        pos_tim = 9
                        xd2_tim = acumy + 10
                        column_letterx_tim = ''
                        column_lettery_tim = ''
                        # CICLO PARA ACUMULAR FORMULAS DE CADA LINEA
                        for i in range(estimacion_c):
                            pasar += 1
                            # pasar los ultimos dos registros
                            if pasar <= (estimacion_c - 2):
                                letra += 2
                                column_lettery2 = get_column_letter((pos + 2) + letra)
                                column_lettery2_tim = get_column_letter((pos_tim + 2) + letra)
                                # STRING ACUMULADO
                                continuacion += ',' + str(column_lettery2 + str(acum_clavex + 9))
                                continuacion_tim += ',' + str(column_lettery2_tim + str(acum_clavex + 9))
                                # print(continuacion, ' continuacion xxxxxxxxxxxxxxxxxxxxxxxxxxx', column_lettery2)
                            else:
                                pass
                        column_letterx = get_column_letter(pos)
                        column_lettery = get_column_letter(pos + 2)
                        column_letterx_tim = get_column_letter(pos_tim)
                        column_lettery_tim = get_column_letter(pos_tim + 2)
                        clave_subx = 0
                        if str(y.clave_linea) == str(clave):
                            # FORMULA PARA SUMAR
                            if estimacion_c == 1:
                                sheet[column_letter + str(acum_clavex + 9)] = y.estimacion
                                sheet[column_letter_timporte + str(acum_clavex + 9)] = y.importe_ejecutado
                                sheet[column_letter + str(acum_clavex + 9)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                                sheet[column_letter_timporte + str(acum_clavex + 9)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                                sheet[column_letter_timporte + str(acum_clavex + 9)].number_format = '[$$-409]#,##0.00;[RED]-[$$-409]#,##0.00'
                            else:
                                sheet[column_letter + str(acum_clavex + 9)] = "=SUM(" + column_letterx + str(acum_clavex + 9) \
                                                                              + "," + column_lettery + str(acum_clavex + 9) + continuacion + ")"
                                sheet[column_letter + str(acum_clavex + 9)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                                sheet[column_letter_timporte + str(acum_clavex + 9)] = "=SUM(" + column_letterx_tim + str(
                                    acum_clavex + 9) + "," + column_lettery_tim + str(acum_clavex + 9) + continuacion_tim + ")"
                                sheet[column_letter_timporte + str(acum_clavex + 9)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                                sheet[column_letter_timporte + str(acum_clavex + 9)].number_format = '[$$-409]#,##0.00;[RED]-[$$-409]#,##0.00'
                        else:
                            sheet[column_letter + str(acum_clavex + 10)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                            sheet[column_letter + str(acum_clavex + 9)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                            sheet[column_letter_timporte + str(acum_clavex + 9)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
                            sheet[column_letter_timporte + str(acum_clavex + 10)].border = Border(top=thin, left=thin,
                                                                                                 right=thin,
                                                                                                 bottom=thin)
                xy = impory
                # total_est = acum_clavex + 9
                total_est = 12 + acum_clavex # + acum_linea_total

    # ------------------------------------ TOTALES DE LAS ESTIMACIONES --------------------------------------
    column_letteru = get_column_letter(pos_total1-1)  # TOTAL
    column_letter_3 = get_column_letter(pos_total1)  # TOTAL CANTIDAD
    column_letter_4 = get_column_letter(pos_total1 + 1)  # TOTAL IMPORTE
    sheet[column_letteru + str(total_est)] = 'TOTAL'
    sheet[column_letteru + str(total_est)].number_format = '[$$-409]#,##0.00;[RED]-[$$-409]#,##0.00'
    sheet[column_letteru + str(total_est)].fill = PatternFill("solid", fgColor="66ADE5")
    sheet[column_letteru + str(total_est)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
    sheet[column_letter_3 + str(total_est)] = "=SUM(" + column_letter_3 + str(11) + ":" + column_letter_3 + str(
        total_est-1) + ")"
    sheet[column_letter_3 + str(total_est)].fill = PatternFill("solid", fgColor="66bb6a")
    sheet[column_letter_3 + str(total_est)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
    sheet[column_letter_3 + str(total_est)].font = Font(color="fafafa", name='Arial', size=9)
    sheet[column_letter_4 + str(total_est)] = "=SUM(" + column_letter_4 + str(11) + ":" + column_letter_4 + str(
        total_est-1) + ")"
    sheet[column_letter_4 + str(total_est)].number_format = '[$$-409]#,##0.00;[RED]-[$$-409]#,##0.00'
    sheet[column_letter_4 + str(total_est)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
    sheet[column_letter_4 + str(total_est)].fill = PatternFill("solid", fgColor="66bb6a")
    sheet[column_letter_4 + str(total_est)].font = Font(color="fafafa", name='Arial', size=9)

    # TOTALES
    for column in range(xy, xy + 1):
        column_letter = get_column_letter(column)
        column_letterq = get_column_letter(column+1)
        # escribe en la celda
        xd2 = 10
        sheet[column_letter + str(xd2)] = 'T.CANTIDAD'
        sheet[column_letter + str(xd2)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
        sheet[column_letter + str(xd2)].fill = PatternFill("solid", fgColor="e65100")
        sheet[column_letter + str(xd2)].font = Font(color="fafafa", name='Arial', size=9, bold=True)
        sheet[column_letter + '9'] = 'TOTALES '
        sheet[column_letter + '9'].alignment = Alignment(horizontal="center", vertical="center")
        sheet.merge_cells("" + column_letter + "9:" + column_letterq + "9")
        sheet[column_letterq + '9'].fill = PatternFill("solid", fgColor="e65100")
        sheet[column_letter + '9'].border = Border(top=thin, left=thin, right=thin, bottom=thin)
        sheet[column_letter + '9'].fill = PatternFill("solid", fgColor="e65100")
        sheet[column_letter + '9'].font = Font(color="fafafa", name='Arial', size=9, bold=True)
    for column in range(xy + 1, xy + 2):
        column_letter = get_column_letter(column)
        # escribe en la celda
        xdx = 10
        sheet[column_letter + str(xdx)] = 'T.IMPORTE'
        sheet[column_letter + str(xdx)].border = Border(top=thin, left=thin, right=thin, bottom=thin)
        sheet[column_letter + str(xdx)].fill = PatternFill("solid", fgColor="e65100")
        sheet[column_letter + str(xdx)].font = Font(color="fafafa", name='Arial', size=9, bold=True)

for column in range(7,8):
    column_letter = get_column_letter(column)
    #escribe en la celda
    sheet[column_letter + "7"] = nombre_partida

for column in range(2,3):
    column_letter = get_column_letter(column)
    #escribe en la celda
    sheet[column_letter + "7"] = contratista

# Save the spreadsheet
workbook.save(filename="resultado.xlsx")
